package com.example.intents

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MyBlogViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_blog_viewer)
    }
}


