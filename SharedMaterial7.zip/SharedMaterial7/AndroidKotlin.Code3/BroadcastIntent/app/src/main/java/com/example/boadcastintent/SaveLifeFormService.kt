package com.example.boadcastintent

import android.app.IntentService

class SaveLifeFormService : IntentService {
    // Receive New Life Form Intent
    override protected void onHandleIntent(Intent intent) {
        // Get New Life Form Data From Intent
        // Open Connection To Database
        // Save New Form Data In Database
    }
}

class PublishLifeFormService : IntentService {
    // Receive New Life Form Intent
    override protected void onHandleIntent(Intent intent) {
        // Get New Life Form Data From Intent
        // Open Connection To Database
        // Save New Form Data In Database
    }
}

class WHONewLifeFormService : IntentService {
    // Receive New Life Form Intent
    override protected void onHandleIntent(Intent intent) {
        // Get New Life Form Data From Intent
        // Open Connection To Database
        // Save New Form Data In Database
    }
}
