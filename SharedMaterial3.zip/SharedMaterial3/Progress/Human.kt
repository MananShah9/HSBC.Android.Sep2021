
package learnKotlin

/*
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar
*/


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// What Is The Capability
// What To Do

// Superpower is Abstact Type
// 		{ { fly, saveWorld}, PHI }
interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() 			= println("Fly Like Spiderman!")
	override fun saveWorld() 	= println("Saveworld Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 			= println("Fly Like Superman!")
	override fun saveWorld() 	= println("Saveworld Like Superman!")
}

class Heman : Superpower {
	override fun fly() 			= println("Fly Like Superman!")
	override fun saveWorld() 	= println("Saveworld Like Superman!")
}

// Human Class Changing All The Time
// class Human: Spiderman() {
// 	override fun fly() 		 = super.fly() 
// 	override fun saveWorld() = super.saveWorld() 
// }

// Composite Design Pattern
// Delegation

// Design Principle
// Law
//		Design Towards Abstract Types Rather Than Concrete Types

// Deduction
//		Object Oriented Design
//			Is Message Driven Programming/Paradigm		
//			Message/Behaviour/Operation First

// Corollary
//	 	Design Towards Interfaces Rather Conceret Classes
//		Prefer interfaces to abstract classes
//		Prefer Composition Over Inheritance
//		Use interfaces only to define types

// Contract/Protocol Driven Design
//		Trust Builds In System
//		Loosely Couples and Mainitable System

// Principle
// Open Close Principle
//		Classes Are Open For Extension But Close For Modification

// Composite Design Pattern
// Delegation
class Human {
	var power: Superpower? 	 = null
	// Wrappter Methods
	fun fly() 		 { power?.fly() 	  }
	fun saveWorld()  { power?.saveWorld() } 
}

fun playWithHuman() {
	val human = Human() 
	human.power = Spiderman()
	human.fly()
	human.saveWorld()

	human.power = Superman()
	human.fly()
	human.saveWorld()

	human.power = Heman()
	human.fly()
	human.saveWorld()	
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!


// Delegation Pattern Supported By Kotlin Language
//																 Delegate
class HumanAgain( power: Superpower = Spiderman() ) : Superpower by power 

//Compiler Will Generate Following Code For The Above Line
// class HumanAgain( power: Spiderman = Spiderman() ) : Spiderman {
// 		fun fly() 		 { power.fly() 	  }
// 		fun saveWorld()  { power.saveWorld() } 
// }

fun playWithHumanAgain() {
	val human = HumanAgain() 
	human.fly()
	human.saveWorld()
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!


fun main() {
	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithHumanAgain")
	playWithHumanAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
}