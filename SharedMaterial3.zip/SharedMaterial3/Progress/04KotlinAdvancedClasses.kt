
package learnKotlin

/*

kotlinc 04KotlinAdvancedClasses.kt -include-runtime -d advancedClasses.jar
java -jar advancedClasses.jar

*/

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

class Client(val name: String, val postalCode: Int) {
	override fun toString() = "Client(name=$name, postalCode=$postalCode)"

	override fun equals(other: Any?) : Boolean {
		if (other == null || other !is Client )
			return false 
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClientClass() {
	val alice = Client("Alice", 11111)
	val gabbar = Client("Gabbar", 22222)
	val aliceAgain = Client("Alice", 11111)

	println(alice) 	// alice.toString()
	println(gabbar)	// gabbar.toString()

	println(alice == aliceAgain) // alice.equals(aliceAgain)
	println(alice == gabbar)     // alice.equals(gabbar)
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Data Classes
// 	Compiler Will Generate Following Functions Code
// 	1. toString Function With All The Properties Values
//	2. equal Function With All Properties Values Compared
//  3. hashCode Function Based On All Properties Values
//  4. Will Generate copy Function Also To Create Copy of IMMUTABLE Properties

// Default Values For Contructor Arguments
data class Client1(val name: String, val postalCode: Int = 100000 )

fun playWithClient1Class() {
	val alice = Client1("Alice", 11111)
	val gabbar = Client1("Gabbar", 22222)
	val aliceAgain = Client1("Alice", 11111)

	println(alice) 	// alice.toString()
	println(gabbar)	// gabbar.toString()

	println(alice == aliceAgain) // alice.equals(aliceAgain)
	println(alice == gabbar)     // alice.equals(gabbar)

	val gabbarCopy = gabbar.copy()
	println(gabbarCopy)

	val gabbarMoved = gabbar.copy(postalCode = 99999)
	println(gabbarMoved)

	val someone = Client1("Someone")
	println(someone)

	val someone1 = Client1("Someone", 99999)
	println(someone1)

	val someone2 = Client1("Someone", postalCode = 555555)
	println(someone2)
}


//________________________________________________________

fun playWithStrings() {

	// String Kerning
	// For Optimisation Compiler Stores One Copy of The Constant
	val name: String = "Gabbar Singh"
	val nameAgain: String = "Gabbar Singh"

	println( nameAgain == name )
	// true
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Defined Type Colour
enum class Colour(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255,0), BLUE(0, 0, 255), ORANGE(200, 200, 10);

	fun doMagic() = println("Doing Magic With Colours...")
}

fun playWithColour(colour: Colour) = when(colour) {
	Colour.RED 		-> "Red Colour"
	Colour.GREEN 	-> "Green Colour"
	Colour.BLUE 	-> "Blue Colour"
	Colour.ORANGE 	-> "Unknown Colour"
}

fun playWithColourAgain() {
	println( playWithColour(Colour.RED) )
	Colour.RED.doMagic()
	Colour.BLUE.doMagic()
} 

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Sealed Classes Are Like Cutomisable Enums
//		Enum Have Only One Common Constructor
//		Where As In Sealed Classed You Can Have Classes With Different Constructor
// interface Expr
sealed class Expr {
	class Num(val value: Int) : Expr()
	class Sum(val left: Expr, val right: Expr) : Expr()
}

fun evaluate(e: Expr) : Int = when(e) {
	is Expr.Num  -> e.value 
	is Expr.Sum  -> evaluate( e.left ) + evaluate( e.right )
	// else 	-> throw IllegalArgumentException("Unknown Arguments...")	
}

fun playWithSealedClasses() {
	// 100 + 800
	println( evaluate( Expr.Sum( Expr.Num(100), Expr.Num(800)) ) )

	// (100 + 800) + 88 
	println( evaluate( Expr.Sum( Expr.Sum( Expr.Num(100), Expr.Num(800) ), Expr.Num(88)) ) )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun getFacebookName(accountID: Int) = "Facebooks : $accountID"

// Interfaces Can Have Properties
interface User {
	val nickname: String
}

class PrivateUser(override val nickname: String) : User

class SubscribingUser(val email: String) : User {
	override val nickname: String
		get() = email.substringBefore('@')
}

class FacebookUSer(val accountID: Int) : User {
	override val nickname = getFacebookName(accountID)
}

fun playWithInterfaceProperties() {
	println( PrivateUser("amarjitlife@gmail.com").nickname )
	println(SubscribingUser("something@yahoo.com").nickname )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Setting Property Backing Field
class User1(val name: String) {
	var address: String = "Unspecified"
		get() {
			// field is Backing Field For Property
			return field
		} 
		
		set(value: String) {
			println("Address Field Going To Change...")
			field = value 
			println("Address Field Changed...")
		}
}

fun playWithBackingField() {
	val alice = User1("Alice")
	println(alice.name)
	println(alice.address)

	alice.address = "Whitefield, Bangalore"
	println(alice.name)
	println(alice.address)
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

class LengthCounter {
	var counter : Int = 0
		private set

	fun addWord(word: String) {
		counter += word.length
	}
}

fun playWithPrivateSetter() {
	val lengthCounter = LengthCounter()
	
	lengthCounter.addWord("Hello")
	println(lengthCounter.counter)

	lengthCounter.addWord("World!")
	println(lengthCounter.counter)
}


//________________________________________________________

// Write Singleton India Class In Java

// Singleton Classes
//		Classes Having Only One Instance

// 1. Make Constructor Private
// 2. Create static Member Variable To Store Reference Of One Instance
// 3. Create static Member Function To Access One Instance
// class India {
// 	private static String name = "India";

//     private static India indiaInstance = null;

//     private India(){
//         System.out.println("Private Constructor of India")
//     }
//     public static India getAnIndiaInstance(){
//         return indiaInstance==null?new India(): indiaInstance;
//     }
// }

//________________________________________________________

// Object Classes
// 		Singleton Classes
//		Classes Having Only One Instance

// Object Class Instance Name is Same As Class Name
// 		i.e. here instance is India

object India {
	val name = "India"
}

fun playWithObjectClasses() {
	// object
	println(India.name)
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

data class Student(val id: Int, val firstName: String, val lastName: String) {
	var fullName = "$firstName $lastName"
}

// Singleton Class
object StudentRegistory {
	val allStudents = mutableListOf<Student>()

	fun addStudent(student: Student) {
		allStudents.add(student)
	}

	fun removeStudent(student: Student) {
		allStudents.remove(student)
	}

	fun listAllStudents() {
		for (student in allStudents) {
			println(student)
		}
	}
}

fun playWithStudentRegistory() {
	val alice = Student(10, "Alice", "Carol")
	val gabbar = Student(11, "Gabbar", "Singh")
	val thakur = Student(100, "Thakur", "Singh")

	StudentRegistory.addStudent(alice)
	StudentRegistory.addStudent(gabbar)
	StudentRegistory.addStudent(thakur)

	StudentRegistory.listAllStudents()
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Companion Objects
//		Companion Classes
//			It's Member Are Accesses/Binded To Enclosing Class

// To Create Class/Type Level Methods
//		Use Companion Objects
//		In Java We Use static Memeber Functions
//		In Kotlin static Keyword Is Not Supported

class Something {
	companion object {
		fun doMagic() {
			println("Doing Magic With Companion Object...")
		}
	}
}

fun playWithCompanionObject() {
	Something.doMagic()
}


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun main() {
	println("\nFunction : playWithClientClass")
	playWithClientClass()

	println("\nFunction : playWithClient1Class")
	playWithClient1Class()

	println("\nFunction : playWithStrings")
	playWithStrings()

	println("\nFunction : playWithColourAgain")
	playWithColourAgain()

	println("\nFunction : playWithSealedClasses")
	playWithSealedClasses()

	println("\nFunction : playWithInterfaceProperties")
	playWithInterfaceProperties()

	println("\nFunction : playWithBackingField")
	playWithBackingField()

	println("\nFunction : playWithPrivateSetter")
	playWithPrivateSetter()

	println("\nFunction : playWithObjectClasses")
	playWithObjectClasses()

	println("\nFunction : playWithStudentRegistory")
	playWithStudentRegistory()

	println("\nFunction : playWithCompanionObject")
	playWithCompanionObject()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

