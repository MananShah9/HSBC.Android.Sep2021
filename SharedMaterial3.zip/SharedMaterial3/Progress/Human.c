
#include <stdio.h>

// class
typedef struct human_type {
	int id;
	char name[100];

	void (*dance)();
} Human;

void bhangraDance() {
	printf("\nDo Bhangraa... Ballleeee Balleee!!!");
}

void kathakDance() {
	printf("\nDo Kathaak... !!!");
}

void main() {
			  // Constructor Job Is To Initialise
	Human h = { 100, "Gabbar Singh", bhangraDance };

	printf("\n Human ID: %d, Name: %s", h.id, h.name );
	h.dance();
}

