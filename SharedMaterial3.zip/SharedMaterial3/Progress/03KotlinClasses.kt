
package learnKotlin

/*

kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar

*/

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// In Kotlin By Default 
// 		Classes And Member Functions Are Final
//		You Can't Inherit From Final Classes 

// In Java By Default 
//		Classes And Member Function Are Open
//		You Can't Inherit From Open Classes

// error: this type is final, so it cannot be inherited from View
open class View {
	// error: 'click' in 'View' is final and cannot be overridden
	open fun click() = println("View Clicked!")
}

// Botton Inheriting From View Class

// error: 'click' hides member of supertype 'View' and needs 'override' modifier
class Button: View() {
	override fun click() 	= println("Button Clicked!")
	fun doMagic() 	= println("Button Magic..")
}

// Extension Functions Doesn't Participate In Inheritance
//		i.e. Can't Be Overridden
fun View.showOff() 		= println("View ShowOff!!!...")
fun Button.showOff() 	= println("Button ShowOff!!!...")

fun playWithClassInheritance() {
	val view: View = View()
	view.click()
	view.showOff() // View ShowOff!!!...

	val button: Button = Button()
	button.click()
	button.doMagic()
	button.showOff() // Button ShowOff!!!...

	// Child Class/Type Object Can Be Stored In Parent Class/Type Reference
	//		Button Is Also Of View Type
	val viewObject: View = Button()
	viewObject.click()
	// viewObject.doMagic() // error: unresolved reference: doMagic
	viewObject.showOff() // View ShowOff!!!...
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Abstract Types
//		Set of Operation and Range Set Empty Set
// What To Be Done

// Interface Member Functions Are Open By Default
//		Can Be Overriden In Concrete Classes
//		i.e. Classes Which Implements Interfaces

interface Clicable1 {
	fun click()
	// Default Implementaiton Of Function
	fun showOff() = println("Clickable1 ShowOff...")
}

interface Focuable1 {
	// Default Implementaiton Of Function
	fun setFocus() = println("Setting Focus!...")
	// Default Implementaiton Of Function
	fun showOff() = println("Focusable1 ShowOff...")
	fun doMagic() = println("Focusable1 doMagic...")
}

// Concerete Classes/Tyoe 
// i.e. It Does Implemention
// How To Be Done
// Class Button1 Implementing Interface Clickable1
class Button1: Clicable1, Focuable1 {
	override fun click() 	= println("Button1 Clicked!!!")
	override fun setFocus() = println("Button1 setFocus...")

	override fun showOff() {
	//	super.showOff() // error: many supertypes available
		super<Clicable1>.showOff()
		super<Focuable1>.showOff()	
	}
}

fun playWithClicableInterface() {
	val button = Button1()

	button.click()
	button.setFocus()
	button.doMagic()
	button.showOff()
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Creating Abstract Type Expr
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

// Snart Type Check and Cast
fun eval(e: Expr) : Int {
	// Here Type Of e Is Expr 
	// is Doing Type Check
	//	If This Type Check Successful (i.e. TRUE)
	//	Then Type Casting Also Happens To Num
	if ( e is Num ) {
		// Here Type Of e Is Num
		return e.value 
	}

	// Here Type Of e Is Expr 
	// is Doing Type Check
	//	If This Type Check Successful (i.e. TRUE)
	//	Then Type Casting Also Happens To Sum

	if (e is Sum) {
		// Here Type Of e Is Sum
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEval() {
	// 100 + 800
	println( eval( Sum( Num(100), Num(800)) ) )

	// (100 + 800) + 88 
	println( eval( Sum( Sum( Num(100), Num(800) ), Num(88)) ) )
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// interface Expr
// class Num(val value: Int) : Expr
// class Sum(val left: Expr, val right: Expr) : Expr

fun evalIf(e: Expr) : Int  = if ( e is Num ) {
		e.value 
	} else if (e is Sum) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unknown Arguments...")	
}

fun playWithEvalIf() {
	// 100 + 800
	println( evalIf( Sum( Num(100), Num(800)) ) )

	// (100 + 800) + 88 
	println( evalIf( Sum( Sum( Num(100), Num(800) ), Num(88)) ) )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun evaluate(e: Expr) : Int = when(e) {
	is Num  -> e.value 
	is Sum  -> evaluate( e.left ) + evaluate( e.right )
	else 	-> throw IllegalArgumentException("Unknown Arguments...")	
}

fun playWithEvaluate() {
	// 100 + 800
	println( evaluate( Sum( Num(100), Num(800)) ) )

	// (100 + 800) + 88 
	println( evaluate( Sum( Sum( Num(100), Num(800) ), Num(88)) ) )
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun main() {

	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	println("\nFunction : playWithClicableInterface")
	playWithClicableInterface()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

