

DAY 1
__________________________________________________________

	A1.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A1.2 : Reading And Code Practice
		KolinNotes1.Shared.pdf

DAY 2
__________________________________________________________

	A2.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A2.2 : Reading And Code Practice
		KolinNotes1.Shared.pdf
		KolinNotes2.Shared.pdf

DAY 3
__________________________________________________________

	A3.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A3.2 : REVISE and Code Practice
		KolinNotes1.Shared.pdf
		KolinNotes2.Shared.pdf

	A3.3 : REVISE and Code Practice
		|-- KotlinNotes5.Shared.pdf
		|-- KotlinNotes6.Shared.pdf
		|-- KotlinNotes7.Shared.pdf
		|-- KotlinNotes8.Shared.pdf
		|-- KotlinNotes9.Shared.pdf

DAY 4
__________________________________________________________

	A4.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A4.2 : COMPLETE FOLLOWING, REVISE and Code Practice
		|-- KotlinNotes5.Shared.pdf
		|-- KotlinNotes6.Shared.pdf
		|-- KotlinNotes7.Shared.pdf
		|-- KotlinNotes8.Shared.pdf
		|-- KotlinNotes9.Shared.pdf
		|-- KotlinNotes10.Shared.pdf
		|-- KotlinNotes11.Shared.pdf

	A4.3 : COMPLETE FOLLOWING, REVISE and Code Practice
		|-- KotlinNotes3.Shared.pdf
		|-- KotlinNotes4.Shared.pdf

	A4.4 : Install Android Studio
		https://developer.android.com/studio
		Download Following File
			android-studio-2020.3.1.24-windows.zip
			922 MiB
		Uzip It in Documents Folder


DAY 5
__________________________________________________________


DAY 6
__________________________________________________________


DAY 7
__________________________________________________________


DAY 8
__________________________________________________________



FUTURE WORK
__________________________________________________________


DAY 1
__________________________________________________________

