
#include <stdio.h>


typdef struct student_type {
	int id;
	char name[100];
} Student; 

// class
typedef struct human_type {
	int id;
	char name[100];

	// Metadata To Handle Messages
	void (*dance)();
} Human;

void bhangraDance() {
	printf("\nDo Bhangraa... Ballleeee Balleee!!!");
}

void kathakDance() {
	printf("\nDo Kathaak... !!!");
}

void main() {

	// h is s Object/Instance of Human Type
	// 		It can recieve messages.
			  // Constructor Job Is To Initialise
	Human h = { 100, "Gabbar Singh", bhangraDance };

	// s is s Variable of Student Type
	Student s = {10, "Ram"};

	printf("\n Human ID: %d, Name: %s", h.id, h.name );
	h.dance();
}

