
#include <stdio.h>

// Function Type
// (int, int) -> int
int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }
int mul(int x, int y) { return x * y; }

// Polymorphism
// Calculator is Polymorphic
// By Passing Behaviour To Behaviour

// Function Type
// (int, int, (int, int) -> int) -> int
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 10, b = 30, result = 0;

	result = calculator(a, b, sum);
	printf("\n Result : %d", result);

	result = calculator(a, b, sub);
	printf("\n Result : %d", result);

	result = calculator(a, b, mul); // Configured As Multiply
	printf("\n Result : %d", result);
}

void playWithFunctionPointer() {
	int a = 10, b = 30, result = 0;

	// Function Pointer
	int (*fptr)() = sum;
	
	result = sum(a, b);
	printf("\n Result : %d", result);

	result = fptr(a, b);
	printf("\n Result : %d", result);
}

void main() {
	printf("\n\nFunction: playWithFunctionPointer");
	playWithFunctionPointer();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
}
