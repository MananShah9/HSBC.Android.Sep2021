
package learnKotlin

/*
kotlinc 05KotlinAdvancedFunctions.kt -include-runtime -d advancedFunctions.jar
java -jar advancedFunctions.jar
*/

//________________________________________________________
// Polymorphism
// 		Mechanism Function Overloading
//			Bassed On umber and/or Types of Arguments 
fun summation(x: Int, y: Int) : Int = x + y
fun summation(x: Double, y: Double) : Double = x + y
fun summation(x: String, y: String) : String = x + y
fun summation(x: Int, y: Int, z: Int) : Int = x + y + z 

fun playWithOverloadedSummation() {
	println( summation( 10, 20 ))
	println( summation( 10, 20, 800 ))
	println( summation( 100.10, 200.20 ))
	println( summation( "Good ", "Morning!"))
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Function Type
// (Int, Int) -> Int
fun sum(x: Int, y: Int) = x + y
fun sub(x: Int, y: Int) = x - y
fun mul(x: Int, y: Int) = x * y

// Polymorphism
// 		Mechanism: Passing Function To Function

// Higher Order Functions
//		Functions Taking Functions As Arguments and/or Returning Functions

// Function Type
// (Int, Int, (Int, Int) -> Int ) -> Int
fun calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithCalculator() {
	val a = 10
	val b = 40
	var result: Int

	result = calculator(a, b, ::sum) // ::sum is Reference To Function
	println("Result : $result")

	result = calculator(a, b, ::sub) // ::sum is Reference To Function
	println("Result : $result")

	result = calculator(a, b, ::mul) // ::sum is Reference To Function
	println("Result : $result")

	val something : (Int, Int) -> Int  = ::sum
	result = something(a, b)
	println("Result : $result")

	val somethingAgain : (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = somethingAgain(a, b, ::mul)
	println("Result : $result")
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun calculatorAgain(x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithLambdaExpressions() {
	val a = 10
	val b = 40
	var result: Int

	// Lambda Expressions
	val sumLambda: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	val subLambda = { x: Int, y: Int -> x - y }
	val mulLambda = { x: Int, y: Int -> x * y }

	result = calculatorAgain(a, b, sumLambda)
	println("Result : $result")

	result = calculatorAgain(a, b, subLambda) // ::sum is Reference To Function
	println("Result : $result")

	result = calculatorAgain(a, b, mulLambda) // ::sum is Reference To Function
	println("Result : $result")
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Higher Order Functions
//		Functions Taking Functions As Arguments and/or Returning Functions

// Function Type : (Int) -> Int
fun stepForward(input: Int) : Int  	= input + 1
fun stepBackward(input: Int) : Int  = input - 1

// Function Returing A Function
// Function Type
// (Boolean) -> (Int) -> Int 
fun chooseStepFunction(backwards: Boolean) : (Int) -> Int {
	return if (backwards) ::stepBackward else ::stepForward
}

fun movingTowardsZero(startValue: Int) {
	var currentValue = startValue
	val moveTowardsZero : (Int) -> Int = chooseStepFunction( currentValue > 0 )
	
	println("Moving Towards Zero...")
	while( currentValue != 0 ) {
		println(currentValue)
		currentValue = moveTowardsZero(currentValue)
	}
	println("Zerooooo!!!")
}

fun playWithMovingTowardsZero() {
	movingTowardsZero(4)
	movingTowardsZero(-4)
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Higher Order Functions
//		Functions Taking Functions As Arguments and/or Returning Functions

// Function Returning A Function
// Function Type
// (Boolean) -> (Int) -> Int 
fun chooseStep(backwards: Boolean) : (Int) -> Int {
	// Function Type : (Int) -> Int
	fun stepForward(input: Int) : Int  	= input + 1
	fun stepBackward(input: Int) : Int  = input - 1

	return if (backwards) ::stepBackward else ::stepForward
}

fun movingTowardsZeroAgain(startValue: Int) {
	var currentValue = startValue
	val moveTowardsZero : (Int) -> Int = chooseStepFunction( currentValue > 0 )
	
	println("Moving Towards Zero...")
	while( currentValue != 0 ) {
		println(currentValue)
		currentValue = moveTowardsZero(currentValue)
	}
	println("Zerooooo!!!")
}

fun playWithMovingTowardsZeroAgain() {
	movingTowardsZeroAgain(4)
	movingTowardsZeroAgain(-4)
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun main() {
	println("\nFunction : playWithOverloadedSummation")
	playWithOverloadedSummation()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithMovingTowardsZero")
	playWithMovingTowardsZero()

	println("\nFunction : playWithMovingTowardsZeroAgain")
	playWithMovingTowardsZeroAgain()

	println("\nFunction : playWithLambdaExpressions")
	playWithLambdaExpressions()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

