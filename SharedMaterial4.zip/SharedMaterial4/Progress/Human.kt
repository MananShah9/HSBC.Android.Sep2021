
package learnKotlin

/*
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar
*/

// static Will Bind Behaviour and State With Type/Class
// nonStatic Behaviour and State Will Bind With Instance

// class ObjectManager {
// 	int objectCount = 0;

// 	static void createObjectAndCount() {
// 		Something.createObject()		
// 	}
// }

// // BAD DESIGN
// // Types 
// class Something {
// 	// Common State Across All The Objects
// 	public static int objectCount = 0;
// 	int some = 100;

// 	static Soemthing createObject() {
// 		objectCount++;
// 		retun new Something(_);
// 	}

// 	static void notoriousFunction(int someValue) {
// 		objectCount = objectCount + someValue;
// 	}

// 	private Something();
// }

// // BAD DESIGN
// class Color {
// 	// Common State Across All The Objects
// 	public static int RED = 0;
// 	public static int GREEN = 0;
// 	public static int BLUE = 0;
// }

// Something.objectCount
// Something.notoriousFunction()

// Something something = new Something();
// something.createObject();
// something.notoriousFunction();

// val RED = 0


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// What Is The Capability
// What To Do

// Superpower is Pure Abstact Type
// 		{ { fly, saveWorld}, PHI }
//		Operations/Behaviour First

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() 			= println("Fly Like Spiderman!")
	override fun saveWorld() 	= println("Saveworld Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 			= println("Fly Like Superman!")
	override fun saveWorld() 	= println("Saveworld Like Superman!")
}

class Heman : Superpower {
	override fun fly() 			= println("Fly Like Superman!")
	override fun saveWorld() 	= println("Saveworld Like Superman!")
}

// Human Class Changing All The Time
// class Human: Spiderman() {
// 	override fun fly() 		 = super.fly() 
// 	override fun saveWorld() = super.saveWorld() 
// }

// Composite Design Pattern
// Delegation

// Design Principle
// Law
//		Design Towards Pure Abstract Types Rather Than Concrete Types

// Deduction
//		Object Oriented Design
//			Is Message Driven Programming/Paradigm		
//			Message/Behaviour/Operation First

// Corollary
//	 	Design Towards Interfaces Rather Conceret Classes
//		Prefer interfaces to abstract classes
//		Prefer Composition Over Inheritance
//		Use interfaces only to define types

// Contract/Protocol Driven Design
//		Trust Builds In System
//		Loosely Couples and Mainitable System

// Principle
// Open Close Principle
//		Classes Are Open For Extension But Close For Modification

// Composite Design Pattern
// Delegation
class Human {
	var power: Superpower? 	 = null
	// Wrappter Methods
	fun fly() 		 { power?.fly() 	  }
	fun saveWorld()  { power?.saveWorld() } 
}

fun playWithHuman() {
	val human = Human() 
	human.power = Spiderman()
	human.fly()
	human.saveWorld()

	human.power = Superman()
	human.fly()
	human.saveWorld()

	human.power = Heman()
	human.fly()
	human.saveWorld()	
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!


// Delegation Pattern Supported By Kotlin Language
//																 Delegate
class HumanAgain( power: Superpower = Spiderman() ) : Superpower by power 

//Compiler Will Generate Following Code For The Above Line
// class HumanAgain( power: Spiderman = Spiderman() ) : Spiderman {
// 		fun fly() 		 { power.fly() 	  }
// 		fun saveWorld()  { power.saveWorld() } 
// }

fun playWithHumanAgain() {
	val human = HumanAgain() 
	human.fly()
	human.saveWorld()
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!


fun main() {
	println("\nFunction : playWithHuman")
	playWithHuman()

	println("\nFunction : playWithHumanAgain")
	playWithHumanAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
}