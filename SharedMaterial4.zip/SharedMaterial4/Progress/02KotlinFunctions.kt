
package learnKotlin

/*

kotlinc 02KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar

*/

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Kotlin Used Java Collection Classes/Types
fun playWithKotlinCollections() {

//	ArrayList<String> something = new ArrayList<String>()

	val set = hashSetOf(10, 80, 90, 777)
	val list = arrayListOf(10, 80, 90, 777)
	val map = hashMapOf( 1 to "One", 7 to "Seven", 10 to "Ten")

	val strings = listOf("First", "Second", "Five", "Six")
	println(strings)
	println(strings.last() )

	val numbers = setOf(10, 80, 90, 777)
	println(numbers)
	println(numbers.maxOrNull())

	println(set.javaClass) 		// class java.util.HashSet
	println(list.javaClass) 	// class java.util.ArrayList
	println(map.javaClass)		// class java.util.HashMap	
	println(strings.javaClass)  // class java.util.Arrays$ArrayList
	println(numbers.javaClass)  // class java.util.LinkedHashSet
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// T Is Type Place Holder
// It Will Be Substited At Compile Time At Place Of Use
fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String 
) : String {

	// Using Java StringBuilder
	val result = StringBuilder(prefix)

	// collection.withIndex() Generates Sequence of Tuples
	// Where Tuple Will Be (Index, Value)
	// (0, "First"), (1, "Second"), (2, "Five"), (3, "Six")

	// Iterating On Sequence Of Tuples and Unpacking/Decluttering Elements Of Tuple
	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringFunction() {
	// RHS Type Inferencing Will Infer Types Of Each Member String
	// Hence Collection Will Become List<String>
	val strings = listOf("First", "Second", "Five", "Six")
	println(strings)

	println( joinToString( strings, " : ", " [ ", " ] ") )
	println( joinToString( strings, " %%% ", " ( ", " ) ") )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun lastChar(string: String) : Char = string.get( string.length - 1 ) 

// Extention Function
//		Add Functionality To Existing Type/Class
// 		lastCharacter() is Extention Function On Type String
fun String.lastCharacter() : Char = this.get( this.length - 1 )

fun playWithLastCharacter() {
	var greeting = "Good Morning!"
	println( lastChar( greeting ) )
	println( greeting.lastCharacter() ) 

	greeting = "Ballee Ballee"
	println( lastChar( greeting ) )
	println( greeting.lastCharacter() )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Extenstion Function
// 		joinToStringExtension() is Extention Function On Type Collection<T>
fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String 
) : String {

	val result = StringBuilder(prefix)

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append(separator)
		result.append(element)
	}

	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringExtenstionFunction() {
	val strings = listOf("First", "Second", "Five", "Six")
	println(strings)

	println( strings.joinToStringExtension( " : ", " [ ", " ] ") )
	println( strings.joinToStringExtension( " %%% ", " ( ", " ) ") )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Extension Property
//		lastChar is Extension Property On Class/Type String
//		IMMutable Extension Property With Custom Getter
val String.lastChar : Char
	get() = get( length - 1 )

// Extension Property
//		lastChar is Extension Property On Class/Type StringBuilder
//		Mutable Extension Property With Custom Getter and Setter
var StringBuilder.lastChar : Char
	get() =  get( length - 1 )
	set( value : Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithLastCharExtensionProperties() {
	var greeting = "Good Morning!"
	println( greeting.lastChar ) 

	greeting = "Ballee Ballee"
	println( greeting.lastChar )

	var string = StringBuilder("Kolin?")
	println( string )
	println( string.lastChar )
	string.lastChar = '#'
	println( string )
	println( string.lastChar )	
}

//________________________________________________________

// class User(val id: Int, val name: String, val address: String )

fun saveUser(user: User) {
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Saving Data Failed : User Name Empty...")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Saving Data Failed : User Address Empty...")
	}

	// Logic For Save User Data....
	// 

	println("Saving User : ${user.name}" )
}

fun playWithSaveUser() {
	saveUser( User( 10, "Ram Singh", "Bangalore") )
	saveUser( User( 11, "Gabbar Singh", "Ramgarh") )
	saveUser( User( 12, "Thakur", "Ramgarh") )
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

class User(val id: Int, val name: String, val address: String )

fun saveUserWithLocalFunction(user: User) { // Enclosing Function
	
	// Local Function
	//		Function Defined Inside Function
	//		Scope And Visibility Within Enclosing Function

	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Saving Data Failed : $fieldName Empty...")
		}
		println("User $fieldName Validated : ${user.name}" )
	}

	validate(user, user.name, "Name")
	validate(user, user.address, "Address")

	// Logic For Save User Data....
	// 

	println("Saving User : ${user.name}" )
}

fun playWithSaveUserWithLocalFunction() {
	saveUserWithLocalFunction( User( 10, "Ram Singh", "Bangalore") )
	saveUserWithLocalFunction( User( 11, "Gabbar Singh", "Ramgarh") )
	saveUserWithLocalFunction( User( 12, "Thakur", "Ramgarh") )
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// class ClassName { 
fun User.validateAndSave() { // Enclosing Function	
	// Local Function
	//		Function Defined Inside Function
	//		Scope And Visibility Within Enclosing Function

	// Localisation
	fun validate( value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Saving Data Failed : $fieldName Empty...")
		}
		println("User $fieldName Validated : ${this.name}" )
	}

	validate(this.name, "Name")
	validate(this.address, "Address")

	// Logic For Save User Data....
	// 

	println("Saving User : ${this.name}" )
}

// Localisation
// Encapsualtion is Special Case Of Localisation
fun playWithSaveUserExtensionFunctionWithLocalFunction() {
	var user = User( 10, "Ram Singh", "Bangalore")
	user.validateAndSave( )
	
	user = User( 11, "Gabbar Singh", "Ramgarh") 
	user.validateAndSave( )

	user = User( 12, "Thakur", "Ramgarh") 
	user.validateAndSave( )
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________


fun main() {

	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithJoinToStringFunction")
	playWithJoinToStringFunction()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringExtenstionFunction")
	playWithJoinToStringExtenstionFunction()

	println("\nFunction : playWithLastCharExtensionProperties")
	playWithLastCharExtensionProperties()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUserWithLocalFunction")
	playWithSaveUserWithLocalFunction()

	println("\nFunction : playWithSaveUserExtensionFunctionWithLocalFunction")
	playWithSaveUserExtensionFunctionWithLocalFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

