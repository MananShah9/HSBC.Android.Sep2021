package practiseClasses

/*
kotlinc 04KotlinAdditionalClassesCode.kt -include-runtime -d additionalClasses.jar
java -jar additionalClasses.jar
*/

import kotlin.math.PI


//----------------Sealed Classes------------------\

sealed class Shape {
    class Circle(val radius: Int) : Shape()
    class Square(val sideLength: Int) : Shape()
    class Rectangle(val width:Int,val height:Int) : Shape()
}

// Sealed classes
fun size(shape: Shape): Double {
    return when (shape) {
        is Shape.Circle -> shape.radius*shape.radius*PI
        is Shape.Square -> (shape.sideLength*shape.sideLength).toDouble()
        is Shape.Rectangle-> (shape.width*shape.height).toDouble()
    }
}

fun playWithSealedClasses() {
    val circle1 = Shape.Circle(4)
    val circle2 = Shape.Circle(2)
    val square1 = Shape.Square(4)
    val square2 = Shape.Square(2)
    val rect1  = Shape.Rectangle(4,5)
    println(size(circle1))
    println(size(circle2))
    println(size(square1))
    println(size(square2))
    println(size(rect1))
}

//----------------------------------------------------------------------


class Car(val carName: String) {
    // Companion Object THing is not required
     companion object EngineSp {
         class Engine(val name:String){
            override fun toString(): String {
                //  return "$engineName in a $carName" // Error cannot see outer scope
                return "Engine $name in Car"
               }
         }
     }

     class Engine(val engineName: String) {
           override fun toString(): String {
            //  return "$engineName in a $carName" // Error cannot see outer scope
            return "Engine $engineName in Car"
           }
    }
}

class Car1(val carName: String) {
    inner class Engine1(val engineName: String) {
        override fun toString(): String {
            return "Engine $engineName in Car: $carName"
        }
    }
}

// Nested and inner classes


fun playWithNestedAndInnerClasses(){
    var car1 = Car("Lamborghini")
    var car2 = Car("Ferrari")
    var car3 = Car1("Ford")
    var car4  =Car1("Jaguar")
    val mazda = Car("mazda")

    // car1.Engine("A") can't access
    Car.EngineSp.Engine("inside")
    println(mazda)
    val mazdaEngine = Car.Engine("toyota") // > toyota engine in a mazda
    println(mazdaEngine)


    println(Car.Engine("Lamborghini"))
    println(car1)
    println(car2)
    println(car3.Engine1("BMW"))
    println(car4.Engine1("HONDA"))
}



//---------------------Inheritance--------------------

// Introducing inheritance
                // Primary Constructor With Default Arguments
data class Grade(val letter: Char = 'F', val points: Double = 0.0, val credits: Double = 0.0 )
                // constructor keyword is Optional In Primary Constructor
open class Person constructor(var firstName: String, var lastName: String) {
    fun fullName() = "$firstName $lastName"
}

/*
class Student(var firstName: String, var lastName: String, var grades: MutableList<Grade> = mutableListOf<Grade>()) {
fun recordGrade(grade: Grade) {
  grades.add(grade)
}
}
*/

open class Student(firstName: String, lastName: String, var grades: MutableList<Grade> = mutableListOf<Grade>()) : Person(firstName, lastName)  {
    open fun recordGrade(grade: Grade) {
        grades.add(grade)
    }
}

fun playWithInheritance(){
    val john = Person(firstName = "Johnny", lastName = "Appleseed")
    val jane = Student(firstName = "Jane", lastName = "Appleseed")
    
    john.fullName() // Johnny Appleseed
    jane.fullName() // Jane Appleseed
    
    val history = Grade(letter = 'B', points = 9.0, credits = 3.0)
    jane.recordGrade(history)
}

//-------------------------Polymorphism-----------------------------------

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    // Following Both Are Same
    //      After Assignment It Default To Getter Body
    // open val minimumPracticeTime: Int = 2 
    open val minimumPracticeTime: Int
        get() { return 2 }
}

class OboePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    // Following Both Are Same
    //      After Assignment It Default To Getter Body
    override val minimumPracticeTime: Int = super.minimumPracticeTime * 2
    // override val minimumPracticeTime: Int 
    //     get() { return super.minimumPracticeTime * 2 }
}


fun phonebookName(person: Person): String = "${person.lastName}, ${person.firstName}"

fun afterClassActivity(student: Student): String = "${student.fullName()} Goes home!"

fun afterClassActivity(student: BandMember): String = "${student.fullName()} Goes to practice!"

fun playWithPolymorphism(){
    val person = Person(firstName = "Johnny", lastName = "Appleseed")
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")

    println(phonebookName(person)) // Appleseed, Johnny
    println(phonebookName(oboePlayer)) // Appleseed, Jane

// // Runtime hierarchy checks

    var hallMonitor = Student(firstName = "Jill", lastName = "Bananapeel")

    hallMonitor = oboePlayer

    println(hallMonitor is OboePlayer) // true, since assigned it to oboePlayer
    println(hallMonitor !is OboePlayer) // also have !is for "not-is"
    println(hallMonitor is Person) // true, because Person is ancestor of OboePlayer

// (oboePlayer as Student).minimumPracticeTime // Error: No longer a band member! //Superclass cannot access subclass properties

    println((hallMonitor as? BandMember)?.minimumPracticeTime) // > 4
    println(afterClassActivity(oboePlayer)) // Goes to practice!
    println(afterClassActivity(oboePlayer as Student)) // Goes home!
}

// // Inheritance, methods, and overrides

class StudentAthlete(firstName: String, lastName: String) : Student(firstName, lastName) {
    val failedClasses = mutableListOf<Grade>()

    override fun recordGrade(grade: Grade) {
        super.recordGrade(grade)

        if (grade.letter == 'F') {
            failedClasses.add(grade)
        }
    }

    val isEligible: Boolean
        get() = failedClasses.size < 3
    // val isEligible: Boolean = failedClasses.size < 3

}

fun playWithInheritanceMethods(){
    val math = Grade(letter = 'B', points = 9.0, credits = 3.0)
    val science = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val physics = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val chemistry = Grade(letter = 'F', points = 9.0, credits = 3.0)

    val dom = StudentAthlete(firstName = "Dom", lastName = "Grady")
    dom.recordGrade(math)
    dom.recordGrade(science)
    dom.recordGrade(physics)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // eligible
    dom.recordGrade(chemistry)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // ineligible

}

//----------------------- Super -----------------------------------------
// // Introducing super

// // When to call super

class StudentAthlete2(firstName: String, lastName: String) : Student(firstName, lastName) {
    var failedClasses = mutableListOf<Grade>()

    override fun recordGrade(grade: Grade) {
        var newFailedClasses = mutableListOf<Grade>()
        for (g in grades) {
            if (g.letter == 'F') {
                newFailedClasses.add(grade)
            }
        }
        failedClasses = newFailedClasses

        super.recordGrade(grade)
    }

    val isEligible: Boolean
        get() = failedClasses.size < 3
}

// // Allowing inheritance

class FinalStudent(firstName: String, lastName: String) : Person(firstName, lastName)

open class AnotherStudent(firstName: String, lastName: String) : Person(firstName, lastName) {

    var grades:MutableList<Grade> = mutableListOf()
    
    open fun recordGrade(grade: Grade) {
        grades.add(grade)
    }

    fun recordTardy():Boolean {
        var count=0
        for(grade in grades){
            if(grade.letter=='F') count+=1
        }
        return count>3
    }
}

class AnotherStudentAthlete(firstName: String, lastName: String) : AnotherStudent(firstName, lastName) {
    override fun recordGrade(grade: Grade) {
        super.grades.add(grade)
    }
    // override fun recordTardy() {} // Build error! //'recordTardy' in 'AnotherStudent' is final and cannot be overridden

}



fun playWithOpen(){
    var f = FinalStudent("A", "B")
    println(f)

    var a  = AnotherStudent("B", "C")
    a.recordGrade(Grade('A', 89.67, 9.8))

    println(a)
    var s = AnotherStudentAthlete("D", "E")

    s.recordGrade(Grade('A', 89.67, 9.8))
    println(s)

}
// ------------------------------Abstract classes----------------------------


abstract class Mammal(val birthDate: String) {
    abstract fun consumeFood()
}



class Human(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() {
        println("Human are omniovores")
    }

    fun createBirthCertificate() {
        println("Born outside wild  $birthDate")
    }
}

class Babboon(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() {
        println("Babboons are carnivorous")
    }

    fun createBirthCertificate() {
        println("Born in wild $birthDate")
    }
}


fun playWithAbstractClass(){
    val human = Human("1/1/2000")
    //  val mammal = Mammal("1/1/2000") // Error: Cannot create an instance of an abstract class
    println(human)
    human.consumeFood()
    val Babboon = Babboon("1/1/2021")
    Babboon.createBirthCertificate()
}


// ---------------------------Secondary constructors----------------------------

open class Geometry {
    // Secondary Constructor
    constructor(size: Int) {
        println("Geometry constructor for size $size")
    }

    // Secondary Constructor
    constructor(size: Int, color: String) : this(size) {
        println("Geometry call to another constructor for size $color")
    }
}

class Circle : Geometry {
    // Secondary Constructor
    constructor(size: Int) : super(size) {
        println("Circle constructor for size with super call")

    }

    // Secondary Constructor
    constructor(size: Int, color: String) : super(size, color) {
        println("Circle constructor for size,color with super call")
    }
}


fun playWithSecodaryConstructor(){

    var c1  =Circle(6)
    var c = Circle(5,"red")
    println(c1)
    println(c)

}



// ------------------------------Visibility modifiers------------------------

data class Privilege(val id: Int, val name: String)

open class User(val username: String, private val id: String, protected var age: Int)

class PrivilegedUser(username: String, id: String, age: Int) : 
User(username, id, age) {
    
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add(privilege)
    }

    fun hasPrivilege(id: Int): Boolean {
        return privileges.map { it.id }.contains(id)
    }

    fun about(): String {
        // return "$username, $id" // Error: id is private
        return "$username, $age" // OK: age is protected
    }
}

fun playWithModifiers(){
    val privilegedUser = PrivilegedUser(username = "sashinka", id = "1234", age = 21)
    val privilege = Privilege(1, "invisibility")
    privilegedUser.addPrivilege(privilege)
    println(privilegedUser.about()) // sashinka, 21
}


//------------------------------When and why to subclass ------------------

data class Sport(val name: String)

class Student2(firstName: String, lastName: String) : Person(firstName, lastName) {
    var grades = mutableListOf<Grade>()
    var sports = mutableListOf<Sport>()
}

// // Single responsibility

// // Strong types

class Team {
    var players = mutableListOf<StudentAthlete>()

    val isEligible: Boolean
        get() {
            for (player in players) {
                if (!player.isEligible) {
                    return false
                }
            }
            return true
        }
}

fun playWithClasses(){
    var p1 = StudentAthlete("A","B")
    var p2 = StudentAthlete("V","K")
    var team = Team()
    team.players.addAll(mutableListOf(p1,p2))

    println(team.isEligible)
}

// // Shared base classes

open class Button {
    open fun press() {
        println("Button pressed")
    }
}

// Prefer interface When Creating Types
// class Image
interface Image

class ImageButton(val image: Image) : Button(){
    override fun press(){
        println("Image button pressed")
    }
}

class TextButton(val text: String) : Button(){
    override fun press(){
        println("Text button pressed")
    }
}

fun playWithSharedBaseClases() {
    var b = Button()
    b.press()

    var i  =ImageButton(Image())
    i.press()

    var t = TextButton("Text")
    t.press()

}


fun main(){
    playWithSealedClasses()
    playWithNestedAndInnerClasses()
    playWithInheritance()
    playWithPolymorphism()
    playWithInheritanceMethods()
    playWithOpen()
    playWithAbstractClass()
    playWithSecodaryConstructor()
    playWithModifiers()
    playWithClasses()
    playWithSharedBaseClases()
}

