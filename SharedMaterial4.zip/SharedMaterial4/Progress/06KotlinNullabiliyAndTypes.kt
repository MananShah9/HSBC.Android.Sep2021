
package practiseClasses

/*
kotlinc 06KotlinNullabiliyAndTypes.kt -include-runtime -d nullability.jar
java -jar nullability.jar
*/

// Kotlin Design Towards Safety
// Design Principle
// 		Design Towards Non-Nullability Rather Than Nullability
//		Prefer Non-Null Types Rather Than Nullable Types

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun playWithNullability() {
    var name: String = "Joe Howard"
    var age: Int = 30
    var occupation: String = "Software Developer & Author"

    println(name)
    println(age)
    println(occupation)
    // Introducing nullable types
    var errorCode: Int?
    errorCode = 100
    println(errorCode)
    errorCode = null
    println(errorCode)

    // Checking for null
    // Inferenced Type Will Int Because NonNullable Types Are Default
//    var result  = 30
	// Nullable Types To Be Annotated Explicitly 
    var result: Int? = 30
    println(result)
    result = null
    println(result)
    
    // result = result + 1
	println(" Result After Addition : ${result + 1}") 
    // Operator call corresponds to a dot-qualified call 
    // 'result.plus(1)' which is not allowed on a nullable receiver 'result`.
    // 

    // Not-null assertion operator
    var authorName: String? = "Joe Howard"
    var authorAge: Int? = 24	

    println(authorName)
    // error: only safe (?.) or 
    // non-null asserted (!!.) calls are allowed on a nullable receiver of type String?
    println(authorName?.uppercase()) // Always Use Safe Access Operator
    println(authorName!!.uppercase())   // Java Style Never Ever Use It
    println(authorAge)

    //println(authorName?.length) // Always Use Safe Access Operator
    authorName = null

    // What is The Data Type of authorLength

    val authorLength: Int? = authorName?.length
    // Compiler Will Generate Following Code For Above Line 
    // val authorLength = if (authorName == null ) null else authorName.length

    println(authorLength) // Always Use Safe Access Operator
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun stringLength(string: String?): Int = if ( string != null ) string.length else 0

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

class Address(val streetAddress: String, val zipCode: Int,
              val city: String, val country: String)

class Company(val name: String, val address: Address?)

class Person(val name: String, val company: Company?)

fun Person.countryName(): String {
	// Optional Chaining
   val country = this.company?.address?.country
   // Compiler Will Generate Following Code For Above Line
   // val addressTemp = if (this.company != null ) company.address else null
   // val country = if ( addressTemp != null ) addressTemp.country else null 

   return if (country != null) country else "Unknown"
}

fun playWithOptionalChaining() {
	val person = Person("Alice", null)
	println( person.countryName() )
}

//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun main() {
	println("\nFunction : playWithNullability")
	playWithNullability()

	println("\nFunction : playWithOptionalChaining")
	playWithOptionalChaining()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}