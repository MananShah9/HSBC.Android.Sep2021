

DAY 1
__________________________________________________________

	A1.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A1.2 : Reading And Code Practice
		KolinNotes1.Shared.pdf

DAY 2
__________________________________________________________

	A2.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A2.2 : Reading And Code Practice
		KolinNotes1.Shared.pdf
		KolinNotes2.Shared.pdf

DAY 3
__________________________________________________________

	A3.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A3.2 : REVISE and Code Practice
		KolinNotes1.Shared.pdf
		KolinNotes2.Shared.pdf

	A3.3 : REVISE and Code Practice
		|-- KotlinNotes5.Shared.pdf
		|-- KotlinNotes6.Shared.pdf
		|-- KotlinNotes7.Shared.pdf
		|-- KotlinNotes8.Shared.pdf
		|-- KotlinNotes9.Shared.pdf

DAY 4
__________________________________________________________

	A4.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A4.2 : COMPLETE FOLLOWING, REVISE and Code Practice
		|-- KotlinNotes5.Shared.pdf
		|-- KotlinNotes6.Shared.pdf
		|-- KotlinNotes7.Shared.pdf
		|-- KotlinNotes8.Shared.pdf
		|-- KotlinNotes9.Shared.pdf
		|-- KotlinNotes10.Shared.pdf
		|-- KotlinNotes11.Shared.pdf

	A4.3 : COMPLETE FOLLOWING, REVISE and Code Practice
		|-- KotlinNotes3.Shared.pdf
		|-- KotlinNotes4.Shared.pdf

	A4.4 : Install Android Studio
		https://developer.android.com/studio
		Download Following File
			android-studio-2020.3.1.24-windows.zip
			922 MiB
		Uzip It in Documents Folder


DAY 5
__________________________________________________________


	A4.1 : Revise And Practice Kotlin Code
		Till Now Whatever Done

	A4.2 : COMPLETE FOLLOWING, REVISE and Code Practice
		|-- KotlinNotes3.Shared.pdf
		|-- KotlinNotes4.Shared.pdf
		|-- KotlinNotes5.Shared.pdf
		|-- KotlinNotes6.Shared.pdf
		|-- KotlinNotes7.Shared.pdf
		|-- KotlinNotes8.Shared.pdf
		|-- KotlinNotes9.Shared.pdf
		|-- KotlinNotes10.Shared.pdf
		|-- KotlinNotes11.Shared.pdf

	A4.3 : EXPLORE FOLLOWING KOTLIN AND JAVA CODE EXAMPLES

		EXPLORATION I
		Explore Following Code Example and Then RAISE HAND!!!
			|-- AndroidJava.Code
			|   |-- Project.03.01.ManifestAndResources
			|   |-- Project.03.04.Activities
			|   |-- Project.03.03.ConfigChanges

		EXPLORATION II
		Explore Following Code Example, Run It
			 -- AndroidKotlin.Code
			    |-- Activities
			    |-- ConfigChanges
			    `-- ManifestAndResourses

DAY 6
__________________________________________________________

	EXPLORATION III
	A4.1 Explore Following Code Example, Run It
		.
		|-- AndroidJava.Code2
		|   |-- Project.04.01.Layouts
		|   |-- Project.04.03.Views
		|   `-- Project.04.04.Adapters
		|
		|-- AndroidKotlin.Code2
		    |-- Layouts
		    |-- Views
		    |-- Adapters


	A4.2 Complete Study Material Part  [ MUST ]
	
		|-- AndroidPresentationsStudy
		    |-- 01.0 Introduction to Android.pdf
		    |-- 01.1 Your first Android app.pdf
		    |-- 01.2 Layouts and resources for the UI.pdf
		    |-- 01.3 Text and scrolling views.pdf
		    |-- 01.4 Resources to help you learn.pdf
		    |-- 02.1 Activities and Intents.pdf
		    |-- 02.2 Activity lifecycle and state.pdf

	A4.3 READING ASSIGNMENTS [ MUST ]

		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/guide/components/intents-filters

		https://developer.android.com/guide/topics/ui/declaring-layout
		https://developer.android.com/guide/topics/ui/layout/linear
		https://developer.android.com/guide/topics/ui/layout/relative
		https://developer.android.com/training/constraint-layout
		
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes

DAY 7
__________________________________________________________


DAY 8
__________________________________________________________



FUTURE WORK
__________________________________________________________


DAY 1
__________________________________________________________

