
package learnKotlin

/*

kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar

*/

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// In Kotlin By Default 
// 		Classes And Member Functions Are Final
//		You Can't Inherit From Final Classes 

// In Java By Default 
//		Classes And Member Function Are Open
//		You Can't Inherit From Open Classes

// error: this type is final, so it cannot be inherited from View
open class View {
	// error: 'click' in 'View' is final and cannot be overridden
	open fun click() = println("View Clicked!")
}

// Botton Inheriting From View Class

// error: 'click' hides member of supertype 'View' and needs 'override' modifier
class Button: View() {
	override fun click() 	= println("Button Clicked!")
	fun doMagic() 	= println("Button Magic..")
}

// Extension Functions Doesn't Participate In Inheritance
//		i.e. Can't Be Overridden
fun View.showOff() 		= println("View ShowOff!!!...")
fun Button.showOff() 	= println("Button ShowOff!!!...")

fun playWithClassInheritance() {
	val view: View = View()
	view.click()
	view.showOff() // View ShowOff!!!...

	val button: Button = Button()
	button.click()
	button.doMagic()
	button.showOff() // Button ShowOff!!!...

	// Child Class/Type Object Can Be Stored In Parent Class/Type Reference
	//		Button Is Also Of View Type
	val viewObject: View = Button()
	viewObject.click()
	// viewObject.doMagic() // error: unresolved reference: doMagic
	viewObject.showOff() // View ShowOff!!!...
}

//________________________________________________________


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun main() {

	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

