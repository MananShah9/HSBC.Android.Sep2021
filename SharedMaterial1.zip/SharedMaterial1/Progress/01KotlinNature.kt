
package learnKotlin

// Seperation of Concerns
/*
kotlinc 01KotlinNature.kt -include-runtime -d nature.jar
java -jar nature.jar
*/


import java.util.TreeMap


fun helloWorld() {
	println("Hello World!!!")
}


// In C/C++/Java
//		if-else Construct is Statement
// In Kotlin
//		if-else Construct is Expression

// Statement Evaluates/Executes
// Expression Is A Statement With Return Value

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b  
	// if( a > b) {
	// 	a 
	// 	a + b
	// } else {
	// 	b 
	// }
}

fun maximum(a: Int, b: Int) = if ( a > b ) a else b  

// _________________________________________________________

fun playWithTypeInferencingAndTypeBinding() {
	
	// error: this variable must either have a type annotation or be initialized
	// val unknown

	val unknown: Int 
	unknown = 8888
	println(unknown)

	// 1. Type Inferencing Will Happen From R H S
	// 2. Type Binding Will Be Done To L H S 
	var some = 9990 // Implicitly Inference Type At Compile Time
	println(some)

	// some = "Ding Dong"

	val someAgain: Int = 9000 // Explicitly Mentioned Type
	println(someAgain)

	val some1 = 999.90
	println(some1)

	val someAgain1: Float = 999.90F
	println(someAgain1)

	val something = "Good Evening!"
	println(something)

	val somethingAgain: String = "Good Evening!"
	println(somethingAgain)

	val something2 = "Good Evening!"
	println(something2)

	val somethingAgain2: String = "Good Evening!"
	println(somethingAgain2)

	val something1 = '#'
	println(something1)

	val somethingAgain1: Char= 'M'
	println(somethingAgain1)

}

// _________________________________________________________

// Kotlin Language Design Principles
// Designed Towards Safety First
//		Design Towards Deterministic System
//		Type Safety


// Designed Towards Expressiveness

// val Means Values 	: Immutable
// var Means Variable 	: Mutable

// Design Principle
// Design Towards Immutability Rather Than Mutablity

// Kotlin Compiler Will Generate Following
//	 	Will Generate Two Member Fields/Variable Each Property viz. name and isMarried
//		Will Generate Getters and Setters For Member Properties
//			One Accessor i.e One Getter Generated For name
//			Two Accessor Generated i.e. Getter and Setter for isMarried
//		Constructor Generated Is Memberwise Initialiser
//			i.e. Will Initialise All The Member Properties

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Created Type Person
class Person(val name: String, var isMarried: Boolean)

fun playWithPerson() {
	val person = Person("Alice", false)

	println(person.name) //person.getPerson()
	// error: val cannot be reassigned
	// person.name = "Alice Carol"	// Can't Modify IMMUTABLE STATE
	// println(person.name)

	println(person.isMarried) //person.isMarried()
	person.isMarried = true   //person.isMarried(true)
	println(person.isMarried)
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// Kotlin Compiler Will Generate Following
//	 	Will Generate Three Member Fields/Variable All Three Properties
//		Will Generate Getters and Setters For Member Properties
//			TWo Accessor Generated i.e. Getters for Two Properties viz. height and width
//		Constructor Generated Is Memberwise Initialiser With Two Properties viz. height and width
//			i.e. Will Initialise All The Member Properties

class  Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean 
		get() { // Explicitly Writing Getter
			return height == width
		}
}

fun playWithRectangle() {
	var rectangle = Rectangle(100, 200)
	println(rectangle.height)
	println(rectangle.width)
	println(rectangle.isSquare)

	rectangle = Rectangle(200, 200)
	println(rectangle.height)
	println(rectangle.width)
	println(rectangle.isSquare)
}

//________________________________________________________
// Comoplete Following Code and Paste In Chat, RAISE HAND!!!

// Write Sum Function With Following Given Signature
// First Attempt
// int sum(int x, int y) {
// 	return x + y;
// }

// Write Sum Function With Following Given Signature
// Return Valid Sum or Print Can't Calculate For Given x and y Vlues
// Second Attempt
// int sum(int x, int y) {

// }


//________________________________________________________

// Defined Type Colour
enum class Colour {
		RED, GREEN, BLUE, ORANGE
}

//  error: 'when' expression must be exhaustive, 
//  	add necessary 'ORANGE' branch or 
// 		'else' branch instead

// BEST PRACTICES
// Always Avoid Else Part
// In Case You Bring Else Block
//		Avoid Exceptions


// error: type mismatch: inferred type is String but Unit was expected
fun playWithColorAgain(colour: Colour) : String {
	// Type Safe Code
	return when(colour) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Colour"
		Colour.ORANGE 	-> "Unknown Colour"
	}
}

fun playWithColorOnceMore(colour: Colour): String {
	// Type Safe Code
	return when(colour) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Colour"
		Colour.ORANGE 	-> "Unknown Colour"
	}
}

// Exceptions Are Not That Exceptional Such That It Break Your Design
fun playWithColor(colour: Colour): String {
	// when is Type Safe Expression
	// It Checks Type Safety
	return when(colour) {
		Colour.RED 		-> "Red Colour"
		Colour.GREEN 	-> "Green Colour"
		Colour.BLUE 	-> "Blue Colour"
		else  			-> "Unknown Colour"
	}
}

//_____________________________________________________

// Definition Driven Design
// Defined Type Colour
enum class Color {
	RED, GREEN, BLUE, ORANGE, YELLOW, VIOLET, INDIGO, UNKNOWN
}

fun mixColors(c1: Color, c2: Color) : Color  {
    return when (setOf(c1, c2)) {
        setOf(Color.RED, Color.YELLOW) 	-> Color.ORANGE
        setOf(Color.YELLOW, Color.BLUE) -> Color.GREEN
        setOf(Color.BLUE, Color.VIOLET) -> Color.INDIGO
        else -> Color.UNKNOWN
        // else -> "Unknown Color"
    }
}

//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun fizzBuzz(i : Int): String {
	// 1. Type Inferencing Will Happen From Following Expression
	return when {
		i % 15 == 0 -> " FizzBuzz "
		i % 5 == 0 	-> " Fizz "
		i % 3 == 0 	-> " Buzz "
		else -> " $i "
	}
}

fun playWithFizzBuzz() {
	for ( i in 1..100 ) {
		print( fizzBuzz(i) )
	}
}

// 1. Type Inferencing Will Happen From R H S
// 2. Type Binding Will Be Done To L H S 
fun fizzBuzzAgain(i : Int) = when {
	i % 15 == 0 -> " FizzBuzz "
	i % 5 == 0 	-> " Fizz "
	i % 3 == 0 	-> " Buzz "
	else -> " $i "
}

fun playWithFizzBuzzAgain() {
	for ( i in 1..100 ) {
		print( fizzBuzzAgain(i) )
	}
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

fun isLetter(c: Char) 	= c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

fun recognize(c: Char) = when (c) {
    in '0'..'9' -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else -> "I don't know..."
}

fun rangesProgressions() {
    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}

fun playWithInOperator() {
    println(isLetter('q'))
    println(isNotDigit('x'))

    println(recognize('8'))
}


//________________________________________________________
// Experiment Following Code and Moment Done RAISE HAND!!!

// import java.util.TreeMap

fun iteratingOverMaps() {
	val binaryRepresentation = TreeMap<Char, String>()

	for( character in 'A'..'Z' ) {
		val binaryValue = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] =  binaryValue
	}

	println("Binary Representation of Each Character...")
	for ( (letter, binary) in binaryRepresentation ) {
		println(" $letter : $binary")
	}
}


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________


fun main() {
	println("Function : helloWorld")
	helloWorld()

	println("Function : max")
	println(max(10, 90)) 
	println(maximum(100, 900)) 

	println("Function : playWithTypeInferencingAndTypeBinding")
	playWithTypeInferencingAndTypeBinding()

	println("Function : playWithPerson")
	playWithPerson()

	println("Function : playWithRectangle")
	playWithRectangle()

	println("Function : playWithColor")
	println(playWithColor(Colour.RED))
	println(playWithColor(Colour.GREEN))
	println(playWithColor(Colour.BLUE))

	println(playWithColorAgain(Colour.RED))
	println(playWithColorAgain(Colour.GREEN))
	println(playWithColorAgain(Colour.BLUE))

	println("Function : mixColors")
	println(mixColors( Color.RED, Color.YELLOW ))
	println(mixColors( Color.YELLOW, Color.BLUE ))
	println(mixColors( Color.YELLOW, Color.GREEN) )

	// var someColor = mixColors( Color.RED, Color.YELLOW)
	// someColor = mixColors( Color.YELLOW, Color.BLUE)
	// someColor = mixColors( Color.YELLOW, Color.GREEN)

	println("Function : playWithFizzBuzz")
	playWithFizzBuzz()

	println("Function : playWithFizzBuzzAgain")
	playWithFizzBuzzAgain()

	println("Function : playWithInOperator")
	playWithInOperator()

	println("Function : iteratingOverMaps")
	iteratingOverMaps()

	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
	// println("Function : ")
}

