
#include <stdio.h>

int sum(int x, int y) {
	return x + y;
}

void main() {
	int a = 2147483647;
	int b = 10;

	int result = 0;

	result = sum(a, b);
	printf("\n Result : %d", result);

// Expected Result : 2147483657
// Result : -2147483639(base)

}


