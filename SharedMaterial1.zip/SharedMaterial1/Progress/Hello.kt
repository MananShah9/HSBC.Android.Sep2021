
package learnKotlin

// Seperation of Concerns

/*
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar
*/

// Paradigm 
// Object Oriented Programming and Functional Programming
//
// 

fun main() {
	println("Hello World!!!")
}


/* 
// Kotlin Compiler WIll Generate

class HelloKt {
	public static void main() {
		println("Hello World!!!");	
	}	
}

//
*/
