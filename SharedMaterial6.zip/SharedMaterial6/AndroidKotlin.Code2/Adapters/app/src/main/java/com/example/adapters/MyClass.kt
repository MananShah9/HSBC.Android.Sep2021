package com.example.adapters

class MyClass(var name: String)
